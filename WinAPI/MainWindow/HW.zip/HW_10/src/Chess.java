public class Chess {
    public Chess(int num) {
        for (int i = 1; i <= num; i++) { // повторяет вывод строки на экран
            //for (int j = 0; j < num; j++) {
                // повторяет вывод * на экран

                System.out.print("* ");
            }
           // System.out.println(); // после вывода строки нужно перейти на новую строку
        }
    }


